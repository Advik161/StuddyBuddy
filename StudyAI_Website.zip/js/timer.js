
let sec=1500,id;function draw(){let m=Math.floor(sec/60),s=sec%60;t.textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;}
function startTimer(){clearInterval(id);id=setInterval(()=>{if(sec>0){sec--;draw();}},1000)}draw();
