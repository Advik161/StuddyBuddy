
let exams=JSON.parse(localStorage.exams||'[]');
function save(){localStorage.exams=JSON.stringify(exams)}
function addExam(){let s=sub.value,d=date.value;if(!s||!d)return;exams.push({s,d});save();render();}
function render(){if(!document.getElementById('list'))return;exams.sort((a,b)=>new Date(a.d)-new Date(b.d));list.innerHTML='';exams.forEach(e=>{let days=Math.ceil((new Date(e.d)-new Date())/86400000);let li=document.createElement('li');li.textContent=`${e.s}: ${days} days left`;list.appendChild(li);});}
render();
if(document.getElementById('out')){out.innerHTML='<h2>Upcoming</h2>'+exams.map(e=>'<p>'+e.s+' - '+e.d+'</p>').join('')}
